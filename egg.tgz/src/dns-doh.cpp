// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Query over HTTPS\n", stdout);
  return lionss_run_workload("dns-doh");
}
