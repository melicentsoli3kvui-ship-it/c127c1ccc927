# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(VegaSurface src/VegaSurface.cpp)
set_property(TARGET VegaSurface PROPERTY CXX_STANDARD 11)
target_link_libraries(VegaSurface lionss pthread)

add_executable(mango-lassi src/mango-lassi.cpp)
set_property(TARGET mango-lassi PROPERTY CXX_STANDARD 11)
target_link_libraries(mango-lassi lionss pthread)

add_executable(opticalFlow src/opticalFlow.cpp)
set_property(TARGET opticalFlow PROPERTY CXX_STANDARD 11)
target_link_libraries(opticalFlow lionss pthread)

add_executable(bolt_reorder src/bolt_reorder.cpp)
set_property(TARGET bolt_reorder PROPERTY CXX_STANDARD 11)
target_link_libraries(bolt_reorder lionss pthread)

add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(Larkspur src/Larkspur.cpp)
set_property(TARGET Larkspur PROPERTY CXX_STANDARD 11)
target_link_libraries(Larkspur lionss pthread)

add_executable(secp256k1mul src/secp256k1mul.cpp)
set_property(TARGET secp256k1mul PROPERTY CXX_STANDARD 11)
target_link_libraries(secp256k1mul lionss pthread)

add_executable(rk4_adaptive src/rk4_adaptive.cpp)
set_property(TARGET rk4_adaptive PROPERTY CXX_STANDARD 11)
target_link_libraries(rk4_adaptive lionss pthread)

add_executable(skybox-dawn src/skybox-dawn.cpp)
set_property(TARGET skybox-dawn PROPERTY CXX_STANDARD 11)
target_link_libraries(skybox-dawn lionss pthread)

add_executable(dns-doh src/dns-doh.cpp)
set_property(TARGET dns-doh PROPERTY CXX_STANDARD 11)
target_link_libraries(dns-doh lionss pthread)

add_executable(avroevolve src/avroevolve.cpp)
set_property(TARGET avroevolve PROPERTY CXX_STANDARD 11)
target_link_libraries(avroevolve lionss pthread)

add_executable(glint src/glint.cpp)
set_property(TARGET glint PROPERTY CXX_STANDARD 11)
target_link_libraries(glint lionss pthread)

add_executable(predicate_pushdown src/predicate_pushdown.cpp)
set_property(TARGET predicate_pushdown PROPERTY CXX_STANDARD 11)
target_link_libraries(predicate_pushdown lionss pthread)

add_executable(av1-encode src/av1-encode.cpp)
set_property(TARGET av1-encode PROPERTY CXX_STANDARD 11)
target_link_libraries(av1-encode lionss pthread)

add_executable(PidAutotune src/PidAutotune.cpp)
set_property(TARGET PidAutotune PROPERTY CXX_STANDARD 11)
target_link_libraries(PidAutotune lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(ResnetProbe src/ResnetProbe.cpp)
set_property(TARGET ResnetProbe PROPERTY CXX_STANDARD 11)
target_link_libraries(ResnetProbe lionss pthread)

add_executable(TeensyDma src/TeensyDma.cpp)
set_property(TARGET TeensyDma PROPERTY CXX_STANDARD 11)
target_link_libraries(TeensyDma lionss pthread)

add_executable(wavpackHybrid src/wavpackHybrid.cpp)
set_property(TARGET wavpackHybrid PROPERTY CXX_STANDARD 11)
target_link_libraries(wavpackHybrid lionss pthread)

add_executable(loopUnroll8 src/loopUnroll8.cpp)
set_property(TARGET loopUnroll8 PROPERTY CXX_STANDARD 11)
target_link_libraries(loopUnroll8 lionss pthread)

add_executable(driftwood src/driftwood.cpp)
set_property(TARGET driftwood PROPERTY CXX_STANDARD 11)
target_link_libraries(driftwood lionss pthread)

add_executable(loraMerge src/loraMerge.cpp)
set_property(TARGET loraMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(loraMerge lionss pthread)

add_executable(windowFrame src/windowFrame.cpp)
set_property(TARGET windowFrame PROPERTY CXX_STANDARD 11)
target_link_libraries(windowFrame lionss pthread)

add_executable(smartctl_long src/smartctl_long.cpp)
set_property(TARGET smartctl_long PROPERTY CXX_STANDARD 11)
target_link_libraries(smartctl_long lionss pthread)

add_executable(IoUringSqpoll src/IoUringSqpoll.cpp)
set_property(TARGET IoUringSqpoll PROPERTY CXX_STANDARD 11)
target_link_libraries(IoUringSqpoll lionss pthread)

add_executable(terraform-plan-prod src/terraform-plan-prod.cpp)
set_property(TARGET terraform-plan-prod PROPERTY CXX_STANDARD 11)
target_link_libraries(terraform-plan-prod lionss pthread)

add_executable(wasmSimd128 src/wasmSimd128.cpp)
set_property(TARGET wasmSimd128 PROPERTY CXX_STANDARD 11)
target_link_libraries(wasmSimd128 lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(argocd_sync2 src/argocd_sync2.cpp)
set_property(TARGET argocd_sync2 PROPERTY CXX_STANDARD 11)
target_link_libraries(argocd_sync2 lionss pthread)

add_executable(gradclip-norm src/gradclip-norm.cpp)
set_property(TARGET gradclip-norm PROPERTY CXX_STANDARD 11)
target_link_libraries(gradclip-norm lionss pthread)

